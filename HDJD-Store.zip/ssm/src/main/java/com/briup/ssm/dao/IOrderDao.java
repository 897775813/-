package com.briup.ssm.dao;


import java.util.List;

import org.springframework.stereotype.Repository;

import com.briup.ssm.common.bean.Order;

@Repository
public interface IOrderDao  {
	public void saveOrder(Order order);
	public List<Order> findOrderById(Long id);
	public Order findOrderByOrderId(Long id);
	public void deleteOrder(Order order);
}
