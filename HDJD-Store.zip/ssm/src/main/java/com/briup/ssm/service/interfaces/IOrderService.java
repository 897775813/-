package com.briup.ssm.service.interfaces;

import java.util.Collection;
import java.util.List;

import com.briup.ssm.common.bean.Line;
import com.briup.ssm.common.bean.Order;
import com.briup.ssm.common.exception.LineException;
import com.briup.ssm.common.exception.OrderException;


public interface IOrderService {
	Long confirmOrder(Order order,Collection<Line> lines) throws OrderException, LineException;
	void deleteOrder(Long id) throws OrderException,LineException;
	List<Order> findById(Long id) throws OrderException;
	Order findByOrderId(Long id) throws OrderException;
}
