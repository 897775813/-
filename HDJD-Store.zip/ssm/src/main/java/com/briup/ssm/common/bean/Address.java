package com.briup.ssm.common.bean;

import org.apache.commons.lang3.StringUtils;

/**
 *地址
 * @author 杨振国，13207083801
 * 
 */
public class Address {
	
	private String country;
	private String province;
	private String city;
	private String address;
	
	public Address() {}
	
	public Address(String addString) {
		if (addString == null) {
			new Address();
		}else {
			String[] adds = addString.split("-");
			this.country=adds[0];
			this.province=adds[1];
			this.city=adds[2];
			this.address=adds[3];
		}
	}
	
	public String getAsString() {
		if (StringUtils.isBlank(country)) {
			country="空";
		}
		if (StringUtils.isBlank(province)) {
			province="空";
		}
		if (StringUtils.isBlank(city)) {
			city="空";
		}
		if (StringUtils.isBlank(address)) {
			address="空";
		}
		
		return country+"-"+province+"-"+city+"-"+address;
	}
	
	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public Address(String country, String province, String city, String address) {
		this.country = country;
		this.province = province;
		this.city = city;
		this.address = address;
	}

	public String getCountry() {
		return country;
	}
	
	public void setCountry(String country) {
		this.country = country;
	}
	
	public String getProvince() {
		return province;
	}
	
	public void setProvince(String province) {
		this.province = province;
	}
	
	public String getCity() {
		return city;
	}
	
	public void setCity(String city) {
		this.city = city;
	}
	@Override
	public String toString() {
		return country+"-"+province+"-"+city+"-"+address;
	}
	
}
