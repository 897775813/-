package com.briup.ssm.service.interfaces;

import com.briup.ssm.common.bean.Customer;
import com.briup.ssm.common.exception.CustomerException;

public interface ICustomerService {
	void register(Customer customer) throws CustomerException;
	Customer login(String name,String password) throws CustomerException;
	void updateCustomer(Customer customer) throws CustomerException;
	Customer findbyId(long id) throws CustomerException;

}
