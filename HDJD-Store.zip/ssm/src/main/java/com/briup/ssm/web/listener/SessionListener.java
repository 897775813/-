package com.briup.ssm.web.listener;

import javax.servlet.ServletContext;
import javax.servlet.annotation.WebListener;
import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;
import org.springframework.context.ApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;
import com.briup.ssm.common.bean.ShoppingCar;
import com.briup.ssm.common.exception.CarLineException;
import com.briup.ssm.common.exception.ShoppingCarException;
import com.briup.ssm.service.interfaces.IShoppingCarService;

/**
 * 会话结束，
 * 要保存购物车信息
 * @author 杨振国，13207083801
 *
 */
@WebListener
public class SessionListener implements HttpSessionListener {

    public void sessionCreated(HttpSessionEvent arg0)  {}

    public void sessionDestroyed(HttpSessionEvent event)  { 
         HttpSession session = event.getSession();
         ServletContext application = session.getServletContext();
         ApplicationContext springContext = WebApplicationContextUtils.getRequiredWebApplicationContext(application);
         IShoppingCarService shoppingcarService = springContext.getBean(IShoppingCarService.class);
         ShoppingCar cart = (ShoppingCar) session.getAttribute("cart"); 
         if (cart!=null) {
				try {
					shoppingcarService.saveCar(cart);
				} catch (ShoppingCarException e) {
					System.out.println("购物车存储异常");
					e.printStackTrace();
				} catch (CarLineException e) {
					System.out.println("购物车行信息存储异常");
					e.printStackTrace();
				}
         }
    }	
	
}
