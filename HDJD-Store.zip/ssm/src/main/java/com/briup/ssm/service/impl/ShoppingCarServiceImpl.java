package com.briup.ssm.service.impl;

import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import com.briup.ssm.common.bean.Carline;
import com.briup.ssm.common.bean.Line;
import com.briup.ssm.common.bean.ShoppingCar;
import com.briup.ssm.common.exception.CarLineException;
import com.briup.ssm.common.exception.ShoppingCarException;
import com.briup.ssm.dao.IShoppingCarDao;
import com.briup.ssm.service.interfaces.ICarlineService;
import com.briup.ssm.service.interfaces.IShoppingCarService;

@Service
public class ShoppingCarServiceImpl implements IShoppingCarService {
	
	@Autowired
	private IShoppingCarDao shoppingCarDao;
	@Autowired
	private ICarlineService carlineService;
	
	@Override
	@Transactional(isolation=Isolation.DEFAULT,readOnly=false,propagation=Propagation.REQUIRED)
	public void saveCar(ShoppingCar car) throws CarLineException {
		/*在库里根据customerid找到购物车，
		 * 如果找不到就添加
		 * 如果找到了就覆盖
		 * 1、覆盖的同时要删除相关的line
		 * 2、再添加相关的line
		 * 
		 * */
		ShoppingCar findCar = shoppingCarDao.findCar(car.getCustomer().getId());
		//最新购物车行信息
		Map<Long, Line> lines = car.getLines();
		//如果没车，就新增购物车信息
		if (findCar==null) {
			//没有车
			Long newCarId = shoppingCarDao.saveShoppingCar(car);
			car.setId(newCarId);
		}else {
			//删除原来的line信息
			carlineService.deletLineByCarId(findCar.getId());
			car.setId(findCar.getId());
		}
		//把line 变为carline 插入新的line信息
		if (lines.size()!=0||lines!=null) {
			for (Line line : lines.values()) {
				Carline carline = new Carline();
				carline.setNum(line.getNum());
				carline.setBook(line.getBook());
				carline.setCar(car);
				carlineService.saveline(carline);
			}
		}
	}
	
	@Override
	@Transactional(isolation=Isolation.DEFAULT,readOnly=true,propagation=Propagation.REQUIRED)
	public ShoppingCar findCarbyCustomerId(Long id) throws ShoppingCarException {
			ShoppingCar findCar = shoppingCarDao.findCar(id);
			if (findCar == null) {
				throw new ShoppingCarException("未找到购物车");
			}
			return findCar;
	}
	
	
}
