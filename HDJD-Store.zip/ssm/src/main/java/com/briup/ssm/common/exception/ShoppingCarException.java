package com.briup.ssm.common.exception;

public class ShoppingCarException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ShoppingCarException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ShoppingCarException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		
	}

	public ShoppingCarException(String message, Throwable cause) {
		super(message, cause);
		
	}

	public ShoppingCarException(String message) {
		super(message);
		
	}

	public ShoppingCarException(Throwable cause) {
		super(cause);
		
	}
	

}
