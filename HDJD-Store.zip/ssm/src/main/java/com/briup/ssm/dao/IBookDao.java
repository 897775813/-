package com.briup.ssm.dao;

import java.util.List;
import org.springframework.stereotype.Repository;

import com.briup.ssm.common.bean.Book;
import com.briup.ssm.common.bean.CustomerEnjoy;

@Repository
public interface IBookDao  {
	List<Book> queryAll();
	Book queryById(Long id);
	List<Book> queryByEnjoy(CustomerEnjoy customerEnjoy);
}
