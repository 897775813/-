package com.briup.ssm.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import com.briup.ssm.common.bean.Book;
import com.briup.ssm.common.bean.CustomerEnjoy;
import com.briup.ssm.common.exception.BookException;
import com.briup.ssm.dao.IBookDao;
import com.briup.ssm.service.interfaces.IBookService;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;

/**
 * 书服务类
 * @author 杨振国 13207083801
 * */
@Service
@Transactional(isolation=Isolation.DEFAULT,readOnly=true,propagation=Propagation.REQUIRED)
public class BookServiceImpl implements IBookService {
	
	@Autowired
	private IBookDao bookDao;
	
	/**
	 * @return 页信息
	 * @param page 页码
	 * @param row 行数
	 * */
	@Override
	public PageInfo<Book> listAllBooks(int page,int row) throws BookException {	
		PageHelper.startPage(page, row);
		List<Book> list = bookDao.queryAll();
		if (list == null) {
			throw new BookException("不好意思，书库空了，新书正在路上~");
		}
		return new PageInfo<Book>(list);
	}
	
	/**
	 * @return 书对象
	 * @param 客户id
	 * */
	@Override
	public Book findById(Long id) throws BookException {
		Book book = bookDao.queryById(id);
		if (book==null) {
			throw new BookException("未找到书籍");
		}
		return book;
	}
	
	/**
	 * @return 书对象集合
	 * @param 客户爱好对象
	 * */
	@Override
	public List<Book> findBooksByCustomerEnjoy(CustomerEnjoy customerEnjoy) throws BookException {
		List<Book> queryByEnjoy = bookDao.queryByEnjoy(customerEnjoy);
		if (queryByEnjoy == null) {
			throw new BookException("查询书籍出现错误");
		}
		return queryByEnjoy;
	}

}
