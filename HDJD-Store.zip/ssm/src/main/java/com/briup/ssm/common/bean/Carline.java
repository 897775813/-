package com.briup.ssm.common.bean;

import java.io.Serializable;

/**
 * 购物车行信息
 * @author 杨振国 13207083801
 * */
public class Carline implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Long id;
	private Integer num;
	/**
	 * 关联关系 -- 多对一  对应一个订单
	 * */
	private ShoppingCar car;
	/**
	 * 关联关系 -- 多对一  对应一类书
	 * */
	private Book book;
	
	/**
	 * 关联关系 -- 多对一  对应一个购物车
	 * */
	public Carline() {
		// TODO Auto-generated constructor stub
	}

	public Carline(Long id, Integer num) {
		this.id = id;
		this.num = num;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Integer getNum() {
		return num;
	}

	public void setNum(Integer num) {
		this.num = num;
	}

	public ShoppingCar getCar() {
		return car;
	}

	public void setCar(ShoppingCar car) {
		this.car = car;
	}

	public Book getBook() {
		return book;
	}

	public void setBook(Book book) {
		this.book = book;
	}

	@Override
	public String toString() {
		return "Carline [id=" + id + ", num=" + num + ", car=" + car + ", book=" + book + "]";
	}
	
	
	
	
	

}
