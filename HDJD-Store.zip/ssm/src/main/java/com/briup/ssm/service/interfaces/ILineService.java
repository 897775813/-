package com.briup.ssm.service.interfaces;

import java.util.List;

import com.briup.ssm.common.bean.Line;
import com.briup.ssm.common.exception.LineException;


public interface ILineService {
	Long saveline(Line line) throws LineException;
	List<Line> findbyid(Long id) throws LineException;
	void deletLine(Long id) throws LineException;

}
