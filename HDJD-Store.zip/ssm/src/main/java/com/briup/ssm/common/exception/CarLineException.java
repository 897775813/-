package com.briup.ssm.common.exception;

public class CarLineException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public CarLineException() {
		super();
	}

	public CarLineException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}

	public CarLineException(String message, Throwable cause) {
		super(message, cause);
	}

	public CarLineException(String message) {
		super(message);
	}

	public CarLineException(Throwable cause) {
		super(cause);
	}
	

}
