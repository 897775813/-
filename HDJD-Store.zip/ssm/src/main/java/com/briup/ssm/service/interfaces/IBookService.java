package com.briup.ssm.service.interfaces;

import java.util.List;

import com.briup.ssm.common.bean.Book;
import com.briup.ssm.common.bean.CustomerEnjoy;
import com.briup.ssm.common.exception.BookException;
import com.github.pagehelper.PageInfo;


public interface IBookService {
	
	PageInfo<Book> listAllBooks(int page,int row) throws BookException ;
	Book findById(Long id) throws BookException;
	List<Book> findBooksByCustomerEnjoy(CustomerEnjoy customerEnjoy) throws BookException;
}
