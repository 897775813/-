package com.briup.ssm.web.controller;

import java.io.File;
import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpSession;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;
import org.json.JSONObject;
import org.json.XML;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.bind.support.SessionStatus;
import org.springframework.web.context.request.WebRequest;
import com.briup.ssm.common.bean.Carline;
import com.briup.ssm.common.bean.Customer;
import com.briup.ssm.common.bean.Line;
import com.briup.ssm.common.bean.ShoppingCar;
import com.briup.ssm.common.exception.CarLineException;
import com.briup.ssm.common.exception.CustomerException;
import com.briup.ssm.common.exception.ShoppingCarException;
import com.briup.ssm.service.interfaces.ICarlineService;
import com.briup.ssm.service.interfaces.ICustomerService;
import com.briup.ssm.service.interfaces.IShoppingCarService;

/**
 * 
 * @author 杨振国，13207083801
 *
 */
@Controller
@SessionAttributes(value={"customer","cart"},types={Customer.class,ShoppingCar.class})
public class UserController {
	
	@Autowired
	private ICustomerService customerService;
	@Autowired
	private IShoppingCarService shoppingCarService;
	@Autowired
	private ICarlineService carlineService;
	
	/**
	 * 每次到登入页面清空session里的客户信息，
	 * 防止客户登入之后直接回退到登入页面，
	 * 防止已登入状态进行登入
	 * @param status
	 * @return
	 */
	@RequestMapping("/login")
	public String showLogin(SessionStatus status){
		status.setComplete();
		return "login";
	}
	
	/**
	 * 用户登入
	 * 成功后 向session添加用户和购物车
	 * 向数据库查询购物车
	 * 如果有购物车
	 * 直接存入session
	 * 如果没有
	 * 新建购物车对象
	 * 存入session
	 * @param userid 用户id
	 * @param password 用户密码
	 * @param webRequest
	 * @param map
	 * @return
	 */
	@RequestMapping("/loginAction")
	public String userLogin(String userid,String password,WebRequest webRequest,Map<String, Object> map){
		try {
			Customer customer = customerService.login(userid, password);
			/*从数据库找购物车，如果没有，就新建一辆，如果有，就给他*/
			ShoppingCar car=null;
			try {
				/*找到购物车*/
				car = shoppingCarService.findCarbyCustomerId(customer.getId());
				/*找相应的行信息*/
				List<Carline> carlines = carlineService.findLinesbyCarId(car.getId());
				/*转化为line信息传给car*/
				for (Carline carline : carlines) {
					Line line = new Line();
					line.setId(carline.getId());
					line.setBook(carline.getBook());
					line.setNum(carline.getNum());
					car.add(line);
				}
			} catch (ShoppingCarException e) {
				/*没有购物车*/
				car = new ShoppingCar();
				car.setCustomer(customer);
			} catch (CarLineException e) {
				webRequest.setAttribute("msg", "加载购物车信息失败！", 1);
				e.printStackTrace();
			}
			map.put("customer", customer);
			map.put("cart", car);
		} catch (CustomerException e) {
			String msg = e.getMessage();
			webRequest.setAttribute("msg", msg, 0);
			return "login";
		} 
		return "redirect:index";
	}
	
	/**
	 * 注册功能
	 * 注册成功直接跳转到登入页面
	 * @param name 用户名
	 * @param customer
	 * @param webRequest
	 * @return
	 */
	@RequestMapping("/registerAction")
	public String userRegister(@RequestParam(value="userid")String name,Customer customer,WebRequest webRequest){
		customer.setName(name);
		try {
			customerService.register(customer);
			webRequest.setAttribute("msg", "注册成功", 1);
		} catch (CustomerException e) {
			String msg = e.getMessage();
			webRequest.setAttribute("msg", msg, 0);
			return "redirect:register";	
		}
		return "redirect:login";
	}
	
	/**
	 * 异步监测用户名是否可用
	 * @param name
	 * @return
	 */
	@RequestMapping("/registerAjaxAction")
	public @ResponseBody String userAjaxRegister(String name){
		try {
			customerService.login(name, "");
		} catch (CustomerException e) {
			if (e.getMessage().equals("用户不存在！")) {
				return "0";
			}
		}
		return "1";
	}
	
	/**
	 * 更新用户信息
	 * 更新成功后返回登录页面
	 * @param userid 客户id
	 * @param customer 页面写回的客户对象
	 * @param session
	 * @return
	 */
	@RequestMapping("/updateCustomer.action")
	public String updateCustomer(@RequestParam(value="userid") String userid,Customer customer,HttpSession session){
		try {
			customerService.updateCustomer(customer);
		} catch (CustomerException e) {
			System.out.println("用户信息修改失败！");
			session.setAttribute("msg", "用户信息修改失败!");
			return "redirect:customer/userinfo";
		}
		session.setAttribute("msg", "用户信息修改成功!");
		return "redirect:login";
	}
	
	/**
	 * 省市三级联动查询省信息
	 * @param country
	 * @param session
	 * @return
	 */
	@RequestMapping(value="/findProvince",produces="text/json;charset=UTF-8")
	public @ResponseBody String findProvince(String country,HttpSession session){
		String realPath = session.getServletContext().getRealPath("/WEB-INF/classes/");
		SAXReader saxReader = new SAXReader();
		try {
				Document read = saxReader.read(new File(realPath+"proAndcity.xml"));
				Element rootElement = read.getRootElement();
				Element selectSingleNode = (Element) rootElement.selectSingleNode("//country[@name='"+country+"']");
				String asXML = selectSingleNode.asXML();
				JSONObject jsonObject = XML.toJSONObject(asXML);
				String json = jsonObject.toString(4);
				return json;
			} catch (DocumentException e) {
				e.printStackTrace();
			}
		return null;
		
	}
	
	/**
	 * 省事三级联动
	 * 异步查询城市
	 * @param province
	 * @param country
	 * @param session
	 * @return
	 */
	@RequestMapping(value="/findCity",produces="text/json;charset=UTF-8")
	public @ResponseBody String findCity(String province,String country,HttpSession session){
		String realPath = session.getServletContext().getRealPath("/WEB-INF/classes/");
		SAXReader saxReader = new SAXReader();
		try {
				Document read = saxReader.read(new File(realPath+"proAndcity.xml"));
				Element rootElement = read.getRootElement();
				Element selectSingleNode = (Element) rootElement.selectSingleNode("//country[@name='"+country+"']//province[@name='"+province+"']");
				String asXML = selectSingleNode.asXML();
				JSONObject jsonObject = XML.toJSONObject(asXML);
				String json = jsonObject.toString(4);
				return json;
			} catch (DocumentException e) {
				e.printStackTrace();
			}
		return null;
		
	}
	
	/**
	 * 注销用户
	 * 清空session
	 * @param status
	 * @param session
	 * @return
	 */
	@RequestMapping("/exit")
	public String exit(SessionStatus status,HttpSession session){
		status.setComplete();
		session.invalidate();
		return "redirect:login";
	}
	
}
