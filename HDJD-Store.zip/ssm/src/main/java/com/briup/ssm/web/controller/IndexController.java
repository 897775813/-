package com.briup.ssm.web.controller;


import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.briup.ssm.common.bean.Book;
import com.briup.ssm.common.bean.CustomerEnjoy;
import com.briup.ssm.common.exception.BookException;
import com.briup.ssm.service.interfaces.IBookService;
import com.github.pagehelper.PageInfo;

@Controller
public class IndexController {
	
	@Autowired
	IBookService bookService;
	
	/**
	 * 
	 * @param session
	 * @param page 页码
	 * @return index视图
	 */
	@RequestMapping(value={"/index","/"})
	public String showIndex(HttpSession session,@RequestParam(value="page",required=false,defaultValue="1") int page){
		try {
			PageInfo<Book> pageInfo = bookService.listAllBooks(page, 3);
			System.out.println("共有几页："+pageInfo.getPageSize());
			session.setAttribute("pageInfo",pageInfo);
		} catch (BookException e) {
			session.setAttribute("msg", e.getMessage());
			e.printStackTrace();
		}
		return "index";
	}
	
	/**
	 * 
	 * @param customerEnjoy 页面写回的客户爱好对象
	 * @param session
	 * @return 根据客户爱好查询到的书籍信息，json数据
	 */
	@RequestMapping("searchBook")
	public @ResponseBody List<Book> searchBook(CustomerEnjoy customerEnjoy,HttpSession session){
		List<Book> findBooksByCustomerEnjoy=null;
		try {
			findBooksByCustomerEnjoy = bookService.findBooksByCustomerEnjoy(customerEnjoy);
			return findBooksByCustomerEnjoy;
		} catch (BookException e) {
			session.setAttribute("msg", "查询书籍错误！");
			e.printStackTrace();
		}
		return findBooksByCustomerEnjoy;
	}
	
}
