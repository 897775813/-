package com.briup.ssm.service.interfaces;

import java.util.List;

import com.briup.ssm.common.bean.Carline;
import com.briup.ssm.common.exception.CarLineException;


public interface ICarlineService {
	void saveline(Carline line) throws CarLineException;
	List<Carline> findLinesbyCarId(Long id) throws CarLineException;
	void deletLineByCarId(Long id) throws CarLineException;
}
