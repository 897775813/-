package com.briup.ssm.common.bean;

import org.apache.commons.lang3.StringUtils;

/**
 * 电话
 * @author 杨振国 13207083801
 * */
public class Phone {
	
	private String homephone;
	private String officephone;
	private String cellphone;
	
	public Phone(String homephone, String officephone, String cellphone) {
		this.homephone = homephone;
		this.officephone = officephone;
		this.cellphone = cellphone;
	}

	public Phone() {}
	
	public Phone(String phone) {
		if (phone==null) {
			new Phone();
		}else {
			String[] split = phone.split("-");
			this.homephone=split[0];
			this.officephone=split[1];
			this.cellphone=split[2];
		}
		
	}
	
	public String getAsString() {
		if (StringUtils.isBlank(homephone)) {
			homephone ="空";
		}
		if (StringUtils.isBlank(officephone)) {
			officephone ="空";
		}
		if (StringUtils.isBlank(cellphone)) {
			cellphone ="空";
		}
		return homephone+"-"+officephone+"-"+cellphone;
	}

	public String getHomephone() {
		return homephone;
	}

	public void setHomephone(String homephone) {
		this.homephone = homephone;
	}

	public String getOfficephone() {
		return officephone;
	}

	public void setOfficephone(String officephone) {
		this.officephone = officephone;
	}

	public String getCellphone() {
		return cellphone;
	}

	public void setCellphone(String cellphone) {
		this.cellphone = cellphone;
	}

	@Override
	public String toString() {
		return homephone+"-"+officephone+"-"+cellphone;
	}

	
}
