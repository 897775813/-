package com.briup.ssm.common.bean;

import org.apache.commons.lang3.StringUtils;

/**
 * 客户爱好
 * @author 杨振国 13207083801
 * */
public class CustomerEnjoy {
	
	private String bookname;
	private String priceround;
	private boolean booktype1;
	private boolean booktype2;
	
	public CustomerEnjoy() {}
	
	public CustomerEnjoy(String bookname, String priceround, boolean booktype1, boolean booktype2) {
		this.bookname = bookname;
		this.priceround = priceround;
		this.booktype1 = booktype1;
		this.booktype2 = booktype2;
	}

	public String getBookname() {
		return bookname;
	}

	public void setBookname(String bookname) {
		if (StringUtils.isBlank(bookname)) {
			bookname = null;
		}
		this.bookname = bookname;
	}

	public String getPriceround() {
		return priceround;
	}

	public void setPriceround(String priceround) {
		this.priceround = priceround;
	}

	public boolean isBooktype1() {
		return booktype1;
	}

	public void setBooktype1(boolean booktype1) {
		this.booktype1 = booktype1;
	}

	public boolean isBooktype2() {
		return booktype2;
	}

	public void setBooktype2(boolean booktype2) {
		this.booktype2 = booktype2;
	}

	@Override
	public String toString() {
		return "CustomerEnjoy [bookname=" + bookname + ", priceround=" + priceround + ", booktype1=" + booktype1
				+ ", booktype2=" + booktype2 + "]";
	}
	
	
	
	

}
