package com.briup.ssm.common.util;

import java.sql.CallableStatement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.apache.ibatis.type.BaseTypeHandler;
import org.apache.ibatis.type.JdbcType;
import com.briup.ssm.common.bean.Address;



public class AddressTypeHandler extends BaseTypeHandler<Address>{

	@Override
	public Address getNullableResult(ResultSet rs, String arg1) throws SQLException {
		return new Address(rs.getString(arg1));
	}

	@Override
	public Address getNullableResult(ResultSet rs, int arg1) throws SQLException {
		return new Address(rs.getString(arg1));
	}

	@Override
	public Address getNullableResult(CallableStatement cs, int arg1) throws SQLException {
		return new Address(cs.getString(arg1));
	}

	@Override
	public void setNonNullParameter(PreparedStatement ps, int i, Address address, JdbcType arg3) throws SQLException {
		ps.setString(i, address.getAsString());
	}


}
