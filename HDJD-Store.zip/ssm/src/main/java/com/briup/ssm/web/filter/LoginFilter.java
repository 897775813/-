package com.briup.ssm.web.filter;

import java.io.IOException;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.briup.ssm.common.bean.Customer;

/**
 * 登入过滤器
 * 过滤除了主页显示，书籍明细查询，登入页面和注册页面，
 * 如果session没有customer信息
 * 则跳回登入页面
 * 并提示未登入
 * @author YZG
 *
 */
@WebFilter(urlPatterns={"/customer/*","/shopcart","*.action"})
public class LoginFilter implements Filter {

    public LoginFilter() {}

	public void destroy() {}

	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		/*如果没有登入
		 * 所有按钮都跳转到login.jsp
		 * */
		HttpServletRequest req=(HttpServletRequest) request;
		HttpServletResponse resp=(HttpServletResponse) response;
		HttpSession session = req.getSession();
		Customer customer = (Customer) session.getAttribute("customer");
		if (customer==null) {
			/*未登录*/
			session.setAttribute("loginmsg", "亲！请先登入~");
			resp.sendRedirect("/SpringMVC-EStore/login");
			return;
		}
		chain.doFilter(req, resp);
	}

	public void init(FilterConfig fConfig) throws ServletException {}

}
