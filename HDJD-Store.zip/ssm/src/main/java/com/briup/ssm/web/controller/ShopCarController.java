package com.briup.ssm.web.controller;

import java.util.Map;
import javax.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.context.request.WebRequest;
import com.briup.ssm.common.bean.Book;
import com.briup.ssm.common.bean.Customer;
import com.briup.ssm.common.bean.Line;
import com.briup.ssm.common.bean.ShoppingCar;
import com.briup.ssm.common.exception.BookException;
import com.briup.ssm.service.interfaces.IBookService;

/**
 * 
 * @author 杨振国，13207083801
 *
 */
@Controller
@SessionAttributes(value={"customer","cart"},types={Customer.class,ShoppingCar.class})
public class ShopCarController {
	
	@Autowired
	IBookService bookService;
	
	/**
	 * 根据书籍id
	 * 找到相应的书籍
	 * 生成新的行信息对象
	 * 将书籍注入给行信息
	 * 在购物车注入行信息
	 * @param productid 书籍id
	 * @param cart
	 * @param session
	 * @return
	 */
	@RequestMapping("/shoppingcart.action")
	public String addShoppingcartLine(String productid,@ModelAttribute("cart")ShoppingCar cart,HttpSession session){
		Book findbook=null;
		try {
			findbook = bookService.findById(Long.parseLong(productid));
		} catch (BookException e) {
			session.setAttribute("msg", e.getMessage());
			System.out.println("加入购物车寻找书籍异常: "+e.getMessage());
			e.printStackTrace();
		}
		//添加一个line
		Line line = new Line();
		line.setBook(findbook);
		cart.add(line);
		return "redirect:shopcart";
	}
	
	/**
	 * 根据书籍id查询书籍
	 * 展现书籍明细
	 * @param productid 书籍id
	 * @param session
	 * @param webRequest
	 * @return
	 */
	@RequestMapping("/productDetail.action")
	public String showProductDetail(String productid,HttpSession session,WebRequest webRequest){
		Map<Long, Book> books = (Map<Long, Book>) session.getServletContext().getAttribute("books");
		//得到要查看的书
		Book book = books.get(Long.parseLong(productid));
		webRequest.setAttribute("book", book, 0);
		return "productDetail";
	}
	
	/**
	 * 异步更新购物车信息
	 * @param num 购物车产品数量
	 * @param bookid 书籍id
	 * @param cart
	 * @return
	 */
	@RequestMapping("updatePro.action")
	public @ResponseBody ShoppingCar updatePro(String num,String bookid,@ModelAttribute("cart")ShoppingCar cart){
		Map<Long, Line> lines = cart.getLines();
		Line line = lines.get(Long.parseLong(bookid));
		line.setNum(Integer.parseInt(num));
		return cart;
	}
	
	/**
	 * 在购物车删除响应行信息
	 * @param productid 书籍id
	 * @param cart
	 * @return
	 */
	@RequestMapping("removeProduct.action")
	public String removeProduct(Long productid,@ModelAttribute("cart")ShoppingCar cart){
		cart.delete(productid);
		return "redirect:shopcart";
	}
	
	/**
	 * 清空购物车信息
	 * @param cart
	 * @return
	 */
	@RequestMapping("removeAllProduct.action")
	public String removeAllProduct(@ModelAttribute("cart")ShoppingCar cart){
		cart.clear();
		return "redirect:shopcart";
	}
	
	/**
	 * 跳转到提交订单页面前
	 * 判断购物车是否有行信息
	 * 如果没有
	 * 则显示还没购买
	 * 如果有
	 * 跳转到提交订单页面
	 * @param cart
	 * @param session
	 * @return
	 */
	@RequestMapping("confirmOrder")
	public String confirmOrder(@ModelAttribute("cart")ShoppingCar cart,HttpSession session){
		if (cart.getLines()==null||cart.getLines().size()==0) {
			session.setAttribute("confirmOrdermsg", "您还没购买物品！");
			return "redirect:shopcart";
		}
		return "redirect:customer/confirmOrder";
	}
}
