package com.briup.ssm.service.interfaces;

import com.briup.ssm.common.bean.ShoppingCar;
import com.briup.ssm.common.exception.CarLineException;
import com.briup.ssm.common.exception.ShoppingCarException;

public interface IShoppingCarService {
	void saveCar(ShoppingCar car) throws ShoppingCarException,CarLineException;
	ShoppingCar findCarbyCustomerId(Long id) throws ShoppingCarException;
}
