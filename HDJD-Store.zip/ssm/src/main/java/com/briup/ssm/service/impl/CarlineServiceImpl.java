package com.briup.ssm.service.impl;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import com.briup.ssm.common.bean.Carline;
import com.briup.ssm.common.exception.CarLineException;
import com.briup.ssm.dao.ICarlineDao;
import com.briup.ssm.service.interfaces.ICarlineService;

/**
 * 购物车行信息服务类
 *@author 杨振国 ，13207083801
 *
 * */
@Service
@Component
public class CarlineServiceImpl implements ICarlineService {
	
	@Autowired
	private ICarlineDao carlineDao;
	
	/**
	 * @param 购物车行信息对象
	 */
	@Override
	@Transactional(isolation=Isolation.DEFAULT,readOnly=false,propagation=Propagation.REQUIRED)
	public void saveline(Carline line) throws CarLineException {
		if (line!=null) {
			carlineDao.insertLine(line);
		}
	}
	
	/**
	 * @return 购物车行信息对象集合
	 * @param 购物车id
	 */
	@Override
	@Transactional(isolation=Isolation.DEFAULT,readOnly=true,propagation=Propagation.REQUIRED)
	public List<Carline> findLinesbyCarId(Long id) throws CarLineException {
		List<Carline> findLinesbyLineId = carlineDao.findLinesbyCarId(id);
		if (findLinesbyLineId == null) {
			throw new CarLineException("购物车行信息查询失败");
		}
		return findLinesbyLineId;
	}

	/**
	 * @param 购物车id
	 */
	@Override
	@Transactional(isolation=Isolation.DEFAULT,readOnly=false,propagation=Propagation.REQUIRED)
	public void deletLineByCarId(Long id) throws CarLineException {
		carlineDao.deleteLinebyCarId(id);
	}

	

}
