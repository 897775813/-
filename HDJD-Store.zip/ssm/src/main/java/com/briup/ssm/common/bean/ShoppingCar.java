package com.briup.ssm.common.bean;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
/**
 * 购物车 （订单项）
 * */
public class ShoppingCar implements Serializable{
	
	private static final long serialVersionUID = 1L;
	// key 商品id value 订单项（商品，数量）
	private Long id;
	private Customer customer;
	private Map<Long, Line> lines = new HashMap<Long, Line>();
	/**
	 * 向购物车中添加产品
	 * 先判断购物车中有没有该产品的订单项目，如果有，在数量上做改变，
	 * 如果没有向map中添加
	 * @param line
	 */
	public void add(Line line){
		if(lines.containsKey(line.getBook().getId())){
			Line oldline = lines.get(line.getBook().getId());
			oldline.setNum(oldline.getNum()+1);
		}else{
			if (line.getNum() == null || line.getNum()==0) {
				line.setNum(1);
			}
				
			lines.put(line.getBook().getId(), line);
		}
	}
	/**
	 * 删除订单
	 * */
	public void delete(Long bookId){
		lines.remove(bookId);
	}
	/**
	 * 获取价钱
	 * */
	public double getCost(){
		Set<Long> keySet = lines.keySet();
		Iterator<Long> iter = keySet.iterator();
		double cost = 0.0;
		while(iter.hasNext()){
			Long key = iter.next();
			Line value = lines.get(key);
			Integer num = value.getNum();
			double price = value.getBook().getPrice();
			double lineCost = num*price;
			cost += lineCost;
		}
		return cost;
	}
	/**
	 * 获取购物车中所有订单项
	 * List<Line>
	 * */
	public Map<Long, Line> getLines(){
		return lines;
	}
	/**
	 * 清空购物车
	 * */
	public void clear(){
		lines.clear();
	}
	public Customer getCustomer() {
		return customer;
	}
	public void setCustomer(Customer customer) {
		this.customer = customer;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}

	@Override
	public String toString() {
		return "ShoppingCar [id=" + id + ", customer=" + customer + ", map=" + lines + "]";
	}
	
	
	
	
}
