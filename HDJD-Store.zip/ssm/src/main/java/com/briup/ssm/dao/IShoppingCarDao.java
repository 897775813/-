package com.briup.ssm.dao;

import org.springframework.stereotype.Repository;

import com.briup.ssm.common.bean.ShoppingCar;
@Repository
public interface IShoppingCarDao {
	Long saveShoppingCar(ShoppingCar car);
	void updateCar(ShoppingCar car);
	ShoppingCar findCar(Long customerid);
}
