package com.briup.ssm.web.controller;

import java.io.UnsupportedEncodingException;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javax.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.context.request.WebRequest;
import com.alipay.api.AlipayApiException;
import com.alipay.api.AlipayClient;
import com.alipay.api.DefaultAlipayClient;
import com.alipay.api.request.AlipayTradePagePayRequest;
import com.briup.ssm.common.bean.Customer;
import com.briup.ssm.common.bean.Line;
import com.briup.ssm.common.bean.Order;
import com.briup.ssm.common.bean.ShoppingCar;
import com.briup.ssm.common.exception.LineException;
import com.briup.ssm.common.exception.OrderException;
import com.briup.ssm.common.util.AlipayConfig;
import com.briup.ssm.service.interfaces.ILineService;
import com.briup.ssm.service.interfaces.IOrderService;

/**
 * 
 * @author 杨振国，13207083801
 *
 */
@Controller
@RequestMapping("/customer")
@SessionAttributes(value={"customer","cart"},types={Customer.class,ShoppingCar.class})
public class OrderController {
	
	@Autowired
	ILineService lineService;
	@Autowired
	IOrderService orderService;
	
	/**
	 * 订单列表展示
	 * @param customer
	 * @param webRequest
	 * @return 
	 */
	@RequestMapping("/order")
	public String showOrder(@ModelAttribute("customer")Customer customer,WebRequest webRequest){
		try {
			List<Order> orders = orderService.findById(customer.getId());
			webRequest.setAttribute("orders", orders, 1);
		} catch (OrderException e) {
			String msg = e.getMessage();
			webRequest.setAttribute("msg", msg, 1);
		}
		return "redirect:showorder";
	}
	
	/**
	 * 形成新订单，
	 * 向订单中添加客户和行信息
	 * 订单和行信息入库
	 * 清空购物车
	 * @param cart session的购物车对象
	 * @param customer session的客户对象
	 * @return
	 */
	@RequestMapping("/saveOrder")
	public String saveOrder(@ModelAttribute("cart") ShoppingCar cart,@ModelAttribute("customer")Customer customer){
		//形成新的订单
		Order order = new Order();
		order.setCustomer(customer);
		order.setCost(cart.getCost());
		order.setOrderDate(new Date());
		Map<Long, Line> lines = cart.getLines();
		for (Line line : lines.values()) {
			line.setOrder(order);
		}
		//订单入库
		try {
			Long orderId = orderService.confirmOrder(order, lines.values());
			order.setId(orderId);
		} catch (OrderException e) {
			System.out.println("订单入库失败");
			e.printStackTrace();
		} catch (LineException e) {
			System.out.println("行信息入库失败");
			e.printStackTrace();
		}
		//删除购物车信息
		cart.clear();
		return "redirect:../index";
	}
	
	/**
	 * 根据订单id查询相应订单信息
	 * @param orderid 页面写会的orderid
	 * @param webRequest
	 * @return
	 */
	@RequestMapping("/orderInfo")
	public String showOrderInfo(Long orderid,WebRequest webRequest){
		try {
			Order order = orderService.findByOrderId(orderid);
			webRequest.setAttribute("order", order, 1);
		} catch (OrderException e) {
			System.out.println("未找到订单信息"+e.getMessage());
			e.printStackTrace();
		}
		return "redirect:showorderinfo";
	}
	
	/**
	 * 根据页面写回的订单id删除订单
	 * @param orderid
	 * @param webRequest
	 * @return
	 */
	@RequestMapping("/removeOrder")
	public String removeOrder(Long orderid,WebRequest webRequest){
		//删除行信息
		try {
			orderService.deleteOrder(orderid);
		} catch (OrderException e) {
			System.out.println("订单删除失败: "+e.getMessage());
			e.printStackTrace();
		} catch (LineException e) {
			System.out.println("行信息删除失败");
			e.printStackTrace();
		}
		return "redirect:order";
	}
	
	/**
	 * 支付功能
	 * @param orderid
	 * @param session
	 * @return
	 */
	@RequestMapping("/Alipay")
	public @ResponseBody String payByAli(String orderid,HttpSession session){
		
		//得到order信息
		Order order=null;
		try {
			order = orderService.findByOrderId(Long.parseLong(orderid));
		} catch (OrderException e) {
			session.setAttribute("paymsg", "订单信息获取失败，支付失败");
			e.printStackTrace();
		}
		
		//商品信息
		Set<Line> lines = order.getLines();
		StringBuffer sb = new StringBuffer();
		for (Line line : lines) {
			sb.append(line.getBook().getName()).append("\t").append("\r\n");
		}
		String orderInfo = sb.toString();
		
		//获得初始化的AlipayClient
		AlipayClient alipayClient = new DefaultAlipayClient(AlipayConfig.gatewayUrl, AlipayConfig.app_id, AlipayConfig.merchant_private_key, "json", AlipayConfig.charset, AlipayConfig.alipay_public_key, AlipayConfig.sign_type);
		
		//设置请求参数
		AlipayTradePagePayRequest alipayRequest = new AlipayTradePagePayRequest();
		alipayRequest.setReturnUrl(AlipayConfig.return_url);
		alipayRequest.setNotifyUrl(AlipayConfig.notify_url);
		
		//商户订单号，商户网站订单系统中唯一订单号，必填
		try {
			String out_trade_no = new String(orderid.getBytes("ISO-8859-1"),"UTF-8");
			//付款金额，必填
			String total_amount = new String((order.getCost()+"").getBytes("ISO-8859-1"),"UTF-8");
			//订单名称，必填
			String subject = new String((order.getOrderDate()+"").getBytes("ISO-8859-1"),"UTF-8");
			//商品描述，可空
			String body = new String(orderInfo.getBytes("ISO-8859-1"),"UTF-8");
			
			alipayRequest.setBizContent("{\"out_trade_no\":\""+ out_trade_no +"\"," 
					+ "\"total_amount\":\""+ total_amount +"\"," 
					+ "\"subject\":\""+ subject +"\"," 
					+ "\"body\":\""+ body +"\"," 
					+ "\"product_code\":\"FAST_INSTANT_TRADE_PAY\"}");
		} catch (UnsupportedEncodingException e1) {
			System.out.println("订单信息获取失败，支付失败：商品信息格式转换错误");
			e1.printStackTrace();
		}
		
		//若想给BizContent增加其他可选请求参数，以增加自定义超时时间参数timeout_express来举例说明
		//alipayRequest.setBizContent("{\"out_trade_no\":\""+ out_trade_no +"\"," 
		//		+ "\"total_amount\":\""+ total_amount +"\"," 
		//		+ "\"subject\":\""+ subject +"\"," 
		//		+ "\"body\":\""+ body +"\"," 
		//		+ "\"timeout_express\":\"10m\"," 
		//		+ "\"product_code\":\"FAST_INSTANT_TRADE_PAY\"}");
		//请求参数可查阅【电脑网站支付的API文档-alipay.trade.page.pay-请求参数】章节
		
		//请求
		
		String result="";
		try {
			result = alipayClient.pageExecute(alipayRequest).getBody();
		} catch (AlipayApiException e) {
			System.out.println("订单信息获取失败，支付页面信息获取失败");
			e.printStackTrace();
		}
		//输出
		return result;
	}
	
}
