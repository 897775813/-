package com.briup.ssm.dao;

import org.springframework.stereotype.Repository;

import com.briup.ssm.common.bean.Customer;
@Repository
public interface ICustomerDao  {
	public Customer findByName(String name);
	public void saveCustomer(Customer customer);
	public void updateCustomer(Customer customer);
	public Customer findById(Long id);
}
