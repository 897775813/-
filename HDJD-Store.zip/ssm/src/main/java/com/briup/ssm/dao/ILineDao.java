package com.briup.ssm.dao;

import java.util.List;
import org.springframework.stereotype.Repository;
import com.briup.ssm.common.bean.Line;

@Repository
public interface ILineDao  {
	void insertLine(Line line);
	List<Line> findLinesbyId(long orderid);
	void deleteLinebyOrderId (long id);
	
}
