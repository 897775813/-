package com.briup.ssm.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import com.briup.ssm.common.bean.Customer;
import com.briup.ssm.common.exception.CustomerException;
import com.briup.ssm.dao.ICustomerDao;
import com.briup.ssm.service.interfaces.ICustomerService;

/**
 * 客户服务类
 * @author 杨振国，13207083801
 *
 */
@Service
public class CustomerServiceImpl implements ICustomerService{
	
	@Autowired
	private ICustomerDao iCustomerDao;
	
	/**
	 * 注册
	 * @param 客户对象
	 */
	@Override
	@Transactional(isolation=Isolation.DEFAULT,readOnly=false,propagation=Propagation.REQUIRED)
	public void register(Customer customer) throws CustomerException {	
			/*
			 * 判断数据库内是否存在该用户，
			 * 如果存在，则抛异常
			 * 如果不存在，则存入数据库
			 * */
		Customer cus = iCustomerDao.findByName(customer.getName());
		if (cus==null) {
			iCustomerDao.saveCustomer(customer);
		}else {
			throw new CustomerException("用户已经存在！");
		}
	}

	/**
	 * 登入
	 * @param name 用户名
	 * @param password 用户密码
	 * @return 客户对象
	 */
	@Override
	@Transactional(isolation=Isolation.DEFAULT,readOnly=true,propagation=Propagation.REQUIRED)
	public Customer login(String name, String password) throws CustomerException {
		Customer customer = iCustomerDao.findByName(name);
		if (customer==null) {
			throw new CustomerException("用户不存在！");
		}
		if (customer.getPassword().equals(password)) {
			return customer;
		}else {
			throw new CustomerException("用户密码不正确！");
		}
	}

	/**
	 * @param customer 需要更新的客户对象
	 */
	@Override
	@Transactional(isolation=Isolation.DEFAULT,readOnly=false,propagation=Propagation.REQUIRED)
	public void updateCustomer(Customer customer) throws CustomerException {
		Customer cus = iCustomerDao.findByName(customer.getName());
		if (cus!=null) {
			customer.setId(cus.getId());
		}else {
			throw new CustomerException("更新失败，未找到用户！");
		}	
		iCustomerDao.updateCustomer(customer);
	}

	/**
	 * 客户查询
	 * 根据客户id查询客户
	 * @return 查询到的客户对象
	 * @param 客户id
	 */
	@Override
	@Transactional(isolation=Isolation.DEFAULT,readOnly=true,propagation=Propagation.REQUIRED)
	public Customer findbyId(long id) throws CustomerException {
		Customer customer = iCustomerDao.findById(id);
				if (customer!=null) {
					return customer;
				}else {
					throw new CustomerException("未找到");
				}
	}
}
