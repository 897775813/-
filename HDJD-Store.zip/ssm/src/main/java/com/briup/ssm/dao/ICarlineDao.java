package com.briup.ssm.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.briup.ssm.common.bean.Carline;


@Repository
public interface ICarlineDao {
	public List<Carline> findLinesbyCarId(long carid);
	public void deleteLinebyCarId(long id);
	public void insertLine(Carline line);
}
