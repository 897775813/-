package com.briup.ssm.service.impl;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import com.briup.ssm.common.bean.Line;
import com.briup.ssm.common.exception.LineException;
import com.briup.ssm.dao.ILineDao;
import com.briup.ssm.service.interfaces.ILineService;

/**
 * 购物车行信息服务类
 * @author 杨振国，13207083801
 *
 */
@Service
@Component
public class LineServiceImpl implements ILineService {

	@Autowired
	private ILineDao lineDao;
	
	/**
	 * @return 行信息自增长生成id返回的id
	 * @param 需要保存的行信息对象
	 */
	@Override
	@Transactional(isolation=Isolation.DEFAULT,readOnly=false,propagation=Propagation.REQUIRED)
	public Long saveline(Line line) throws LineException {
		if (line !=null) {
			lineDao.insertLine(line);
		}
		return line.getId();
	}
	
	/**
	 * @return 行信息对象集合
	 * @param order的id
	 */
	@Override
	@Transactional(isolation=Isolation.DEFAULT,readOnly=true,propagation=Propagation.REQUIRED)
	public List<Line> findbyid(Long id) throws LineException {
		List<Line> lines = lineDao.findLinesbyId(id);
		if (lines == null) {
			throw new LineException("未找到行信息");
		}
		return lines;
	}
	
	/**
	 * @param 行信息id
	 */
	@Override
	@Transactional(isolation=Isolation.DEFAULT,readOnly=false,propagation=Propagation.REQUIRED)
	public void deletLine(Long id) throws LineException {
		lineDao.deleteLinebyOrderId(id);
	}
}
