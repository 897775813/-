﻿package com.briup.ssm.common.util;

import java.io.FileWriter;
import java.io.IOException;

/* *
 *类名：AlipayConfig
 *功能：基础配置类
 *详细：设置帐户有关信息及返回路径
 *修改日期：2017-04-05
 *说明：
 *以下代码只是为了方便商户测试而提供的样例代码，商户可以根据自己网站的需要，按照技术文档编写,并非一定要使用该代码。
 *该代码仅供学习和研究支付宝接口使用，只是提供一个参考。
 */

public class AlipayConfig {
	
//↓↓↓↓↓↓↓↓↓↓请在这里配置您的基本信息↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓

	// 应用ID,您的APPID，收款账号既是您的APPID对应支付宝账号
	public static String app_id = "2016091900544548";
	
	// 商户私钥，您的PKCS8格式RSA2私钥
	public static String merchant_private_key = "MIIEvAIBADANBgkqhkiG9w0BAQEFAASCBKYwggSiAgEAAoIBAQCPFku0iamhuqjdiix83R32QV1wXoEXjhyWBFrKrRkD2T1smMjHMHZlNnBqbWlK5/Fw/eu6JsAmuFWS7k5Iq0/WDkUdyEM0nxmsyJHUgS4XT4LuvO+bjCm0HlLgG91gyYGIrIboil0433c8xtYGRDcdYhBIQpNMitTKHpsn5HXKogP1nJev4RMF7urR8WtUdRBo2BaYmm87ri4kPByuv8jWzRH44K+6vnbr/vhwYPDDgQg16clNMIaJw3TjWMlqVLMUvRbM+vjXqYFMRcef85Uoj7dY0JRC827SL772/2IEvE+OVzBuZ9CkVonnauaJ5mvOCJgmr/tr89lBE416arLlAgMBAAECggEAdzeQZB++4i1vvQX/AxoIeMEFZTaYQFP7pVKDgxKuIPLDptO1laDfRH0TNNlsPSj7lbU6zqKyvpAfXIiJWSrDHgpNs/7DX/ifn8KNHo1zJaDt6pQo32Ts6lHJo0gULyw1bPaygNWnzlcCNfVFJXt4oFawUkSGDeQuXykZBSforKcJl6p+o6+rI4yG6Bp/3ug2rQ3TPf7SkI5/fi9WURSKbBk5irgl3WUlmqE8ldHmNAI7G1bswnunTA22fCsy4Iznz6HlnJCHboN3Vm9LMD5xoRd0XyZ7flGR1QHF4oaQkLOA21p31ltb5G+V3g/uXaZKZImdXjTpGJurAXFTvEzdAQKBgQDGmlcxxHETVhEhy2Q5+HUY+wmmiBBBNAHhzrUYWqijmUbpfA/j6EoS6mJcQw12lmf6AQN5VVD7xSwXAqdfEru7Fj2YUQ8qnyfgr7S9BXBbFCV4ckejoNdWW6OdjQU2fR83PQXaoPOlnVqXaH2rzXgquG8OKXAH+AUlhgr76pW1sQKBgQC4cJygkclOmqh1WIixMYE0yJHOqBfuwnMxxr75X+kInrRu8ZCtHajd5zZyP9LnuTN20srIPqVXr4IITEqAlavx/ZcBOEl6UsjmTu9JlDj+LybqMudBlkpNgPncWDJz4g9epcQ9Zpih7G6cv5kZvePuLpQ5EeyFcH88HhFNVH55dQKBgHvAjpanRqJ63eAGAeURib3QJ5pKbH6ErquLB1MuoqiWiRZSRQCJrSaOQE4nRgtf+1hQK17+p6DKowePksVuQeZ5HFZ+JAo19D5QnjmuWu2V5ydfZn5yadwY7CHvTpE+dCYSc0RhSJEpNNrltHFKbheIp0LW1UVR6bsRBGUnLrRxAoGAOZA78glOENBIH0egcd0HfFfU2fCwd34Mwc5LsDz02BHgMngGNWF6YLdW0NWGl3e/zif/zftvUyydosVcw0DzRzVkOac9l4Xa2bZtDEPMfdhths6YSmoDiqjkUpbcODqnnVyTIK6ymGbYJufNerE/QAkdjapAbW0s6LBhqgbi6jkCgYBwPDsGpSwKkVfgQlI7adwggzVNTC0eGHk57BoSBssv47JFi0iQQv01gDDiVywc5jMbOt8i50dURMA4ckfcvh8jrbVrPbn/q2RwG944XVUgVuGEvI1QcbOzDIiQE9kWnkB4VyyZ/WxXYbeOs2TpEz/giSV3OVfQYVfKJTzNlMKFOA==";	
	// 支付宝公钥,查看地址：https://openhome.alipay.com/platform/keyManage.htm 对应APPID下的支付宝公钥。
    public static String alipay_public_key = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAvnKWs6EAlPGW7uYKuZiBJ7dN8ViOfwKV6C75bOuJ8TUHMZE3AjlbsS3EqFnafiaJ8iA9/ycsNClefsJJQ87UBzfypDFCBIapOa04pe49wOmWWPjB9yuzdSxYCxLNlHlSD+tWtZ9t7XcAio6IEuVK5TGh2bv57wu2nSh5GmTtYcANvNo2uWkEfFPBQRA+VbXi2STUoiQ+YFbTcJrWshYJUu5JDBLN5fGADGV75sU9+B5Ft6LoF/qxqxbeDsGVwIR8/8aP4jHuXUrenAh+szp/X2Bgs+KCtRpCNpVSU/6SS2LQ7ENv3I3bzgg+04+kvIfecvPNy3FhF1e/hC+l9XjW0wIDAQAB";

	// 服务器异步通知页面路径  需http://格式的完整路径，不能加?id=123这类自定义参数，必须外网可以正常访问
	public static String notify_url = "http://localhost:8080/alipay.trade.page.pay-JAVA-UTF-8/notify_url.jsp";

	// 页面跳转同步通知页面路径 需http://格式的完整路径，不能加?id=123这类自定义参数，必须外网可以正常访问
	public static String return_url = "http://localhost:8080/SpringMVC-EStore/customer/order";

	// 签名方式
	public static String sign_type = "RSA2";
	
	// 字符编码格式
	public static String charset = "utf-8";
	
	// 支付宝网关
	public static String gatewayUrl = "	https://openapi.alipaydev.com/gateway.do";
	
	// 支付宝网关
	public static String log_path = "C:\\";


//↑↑↑↑↑↑↑↑↑↑请在这里配置您的基本信息↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑

    /** 
     * 写日志，方便测试（看网站需求，也可以改成把记录存入数据库）
     * @param sWord 要写入日志里的文本内容
     */
    public static void logResult(String sWord) {
        FileWriter writer = null;
        try {
//        	System.out.println(log_path + "alipay_log_" + System.currentTimeMillis()+".txt");
            writer = new FileWriter(log_path + "alipay_log_" + System.currentTimeMillis()+".txt");
            writer.write(sWord);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (writer != null) {
                try {
                    writer.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}

