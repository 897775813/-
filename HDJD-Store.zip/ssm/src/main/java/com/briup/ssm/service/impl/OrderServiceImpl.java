package com.briup.ssm.service.impl;

import java.util.Collection;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import com.briup.ssm.common.bean.Line;
import com.briup.ssm.common.bean.Order;
import com.briup.ssm.common.exception.LineException;
import com.briup.ssm.common.exception.OrderException;
import com.briup.ssm.dao.IOrderDao;
import com.briup.ssm.service.interfaces.ILineService;
import com.briup.ssm.service.interfaces.IOrderService;

/**
 * 订单服务
 * @author 杨振国，13207083801
 *
 */
@Service
public class OrderServiceImpl implements IOrderService {
	
	@Autowired
	private IOrderDao orderDao;
	@Autowired
	private ILineService lineService;
	
	/**
	 * @param order 要保存的订单对象
	 * @param lines 要保存的订单行信息
	 * @return 订单保存自增长的id
	 */
	@Override
	@Transactional(isolation=Isolation.DEFAULT,readOnly=false,propagation=Propagation.REQUIRED)
	public Long confirmOrder(Order order, Collection<Line> lines) throws OrderException, LineException {
		if (order!=null) {
			orderDao.saveOrder(order);
			for (Line line : lines) {
				lineService.saveline(line);
			}
		}
		return order.getId();	
	}
	
	/**
	 * @param id 订单id
	 */
	@Override
	@Transactional(isolation=Isolation.DEFAULT,readOnly=false,propagation=Propagation.REQUIRED)
	public void deleteOrder(Long id) throws OrderException, LineException {
		Order order = orderDao.findOrderByOrderId(id);
		if (order==null) {
			throw new OrderException("无法找到相应订单");
		}
		lineService.deletLine(id);
		orderDao.deleteOrder(order);
	}
	
	/**
	 * @param id 客户id
	 * @return 查询到的订单对象集合
	 */
	@Override
	@Transactional(isolation=Isolation.DEFAULT,readOnly=true,propagation=Propagation.REQUIRED)
	public List<Order> findById(Long id) throws OrderException {
		List<Order> orders = orderDao.findOrderById(id);
		if (orders==null) {
			throw new OrderException("无法找到相应订单");
		}
		return orders;
	}
	
	/**
	 * @param id 订单id
	 * @return 查询到的订单对象
	 */
	@Override
	@Transactional(isolation=Isolation.DEFAULT,readOnly=true,propagation=Propagation.REQUIRED)
	public Order findByOrderId(Long id) throws OrderException {
		Order order = orderDao.findOrderByOrderId(id);
		System.out.println(order);
		if (order==null) {
			throw new OrderException("无法找到相应订单");
		}
		return order;
	}

}
