
function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}

function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_findObj(n, d) { //v4.0
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && document.getElementById) x=document.getElementById(n); return x;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}

function checkMe() {
   if(document.login.userid.value == "") {
          alert("请输入你的姓名！");
          document.login.userid.focus();
          return false;
    }
    if(document.login.password.value == "") {
          alert("请输入你的密码！");
          document.login.password.focus();
          return false;
    }
    document.login.submit();
}

function checkReg() {
	var temp;
	temp = new String(document.reg.password.value);
	if(document.reg.userid.value == "") {
		alert("请输入用户名!");
		document.reg.userid.focus();
		return false;
	}
	if(document.reg.password.value == "") {
		alert("请输入密码!");
		document.reg.password.focus();
		return false;
	}else if(temp.length < 6 || temp.length > 8) {
		alert("您的密码少于6位或多于8位!");
		document.reg.password.focus();
		return false;
	}
	if(document.reg.password2.value == "") {
		alert("请再次输入密码!");
		document.reg.password2.focus();
		return false;
	} else if(document.reg.password.value != document.reg.password2.value) {
		alert("您二次密码输入不一致!");
		document.reg.password.value = "";
		document.reg.password2.value = "";
		document.reg.password.focus();
		return false;
	}
	if(document.reg.email.value != "" & IsEmail(document.reg.email.value)) {
		alert("您的E-mail不符合规范!");
		document.reg.email.focus();
		return false;
	}
	document.reg.submit();
}

function IsEmail(item){
	var etext
	var elen
	var i
	var aa
	var uyear,umonth,uday
	etext=item;
	elen=etext.length;
	if (elen<5)
 		return true;
	i= etext.indexOf("@",0)
	if (i==0 || i==-1 || i==elen-1)
 		return true;
	else
 		{if (etext.indexOf("@",i+1)!=-1)
  			return true;}
		if (etext.indexOf("..",i+1)!=-1)
 		return true;
	i=etext.indexOf(".",0)
	if (i==0 || i==-1 || etext.charAt(elen-1)=='.')
 		return true;
	if ( etext.charAt(0)=='-' ||  etext.charAt(elen-1)=='-')
 		return true;
	if ( etext.charAt(0)=='_' ||  etext.charAt(elen-1)=='_')
 		return true;
	for (i=0;i<=elen-1;i++)
		{ aa=etext.charAt(i)
 		 if (!((aa=='.') || (aa=='@') || (aa=='-') ||(aa=='_') || (aa>='0' && aa<='9') || (aa>='a' && aa<='z') || (aa>='A' && aa<='Z')))
   			return true;
		}
	return false;
}


function numUpdate(bookid,num){
	$.ajax({
		type:'GET',
		url:'updatePro.action?bookid='+bookid+'&num='+num,
		contentType : 'application/json',
		success:function(date){
			//{"id":null,"customer":null,"lines":
			//{"1":{"id":null,"num":2,"order":null,"book":
			//{"id":1,"name":"精通Hibernate:Java对象持久化技术详解","price":59.0}}},"cost":118.0}
			var cost=date.cost;
			var linenum=date.lines[bookid].num;
			var bookprice=date.lines[bookid].book.price;
			var lineprice=linenum*bookprice;
			$("#cost").text(cost);
			$("#"+bookid).text(lineprice);
		}
	})
}


function findCity(){
	var counrty=$('#country').val();
	var province=$('#province').val();
	console.log(province);
	$.ajax({
		type:'GET',
		url:'findCity?province='+province+'&country='+counrty,
		contentType : 'application/json',
		success:function(date){
			$('#city').empty();
			var citys=date.province.city;
			$.each(citys,function(index,value){
				  var city=$('#city');
				  city.append("<option value='"+value+"'>"+value+"</option>");
			});
		}
	})
	
}

function findProvince(){
	var counrty=$('#country').val();
	$.ajax({
		type:'GET',
		url:'findProvince?country='+counrty,
		contentType : 'application/json',
		success:function(date){
			$('#province').empty();
			var provinces=date.country.province;
			if(counrty=='中国'){
				$.each(provinces,function(index,value){
				        var province=$('#province');
				        province.append("<option value='"+value.name+"'>"+value.name+"</option>");
				    });
				findCity();
			}else{
				 var province=$('#province');
			        province.append("<option value='"+provinces.name+"'>"+provinces.name+"</option>");
			        findCity();
			}
		}
	})
}

function checkname(){
	var userid=$("#username").val();
	$.ajax({
		type:'GET',
		url:'registerAjaxAction?name='+userid,
		contentType : 'application/json',
		success:function(date){
			if(date=="1"){
				$("#spanEle").html("<font color='#FF0000'>用户名已经存在</font>");
				$("#regbtn").attr("disabled", true); 
			}else{
				$("#spanEle").html("<font color='#00FF99'>用户名可以使用</font>");
				$("#regbtn").attr("disabled", false); 
			}
		}
	})
}

function searchBook(){
	var bookname=$("#bookname").val();
	var priceround=$("#priceround").val();
	var booktype1=$("#booktype1").prop("checked");
	var booktype2=$("#booktype2").prop("checked");
	$("#stid").empty();
	$.ajax({
		type:'GET',
		url:'searchBook?bookname='+bookname+'&priceround='+priceround+'&booktype1='+booktype1+'&booktype2='+booktype2,
		contentType : 'application/json',
		success:function(date){
			$("#stid").append("<table cellpadding=3 cellspacing=1 align=center class=tableborder1 id='searchtable'>");
			$("#searchtable").append("<tr><td valign=middle align=center height=25 background='images/bg2.gif' width=''><font color='#ffffff'><b>序号</b></font></td><td valign=middle align=center height=25 background='images/bg2.gif' width=''><font color='#ffffff'><b>产品名称</b></font></td><td valign=middle align=center height=25 background='images/bg2.gif' width=''><font color='#ffffff'><b>价格</b></font></td><td valign=middle align=center height=25 background='images/bg2.gif' width=''><font color='#ffffff'><b>操作</b></font></td></tr>");
			$.each(date,function(index,value){
				$("#searchtable").append("<tr>" +
						"<td class=tablebody2 valign=middle align=center width=''>"+index+"</td>" +
						"<td class=tablebody1 valign=middle width=''>&nbsp;&nbsp;" +
						"<a href='productDetail.action?productid="+value.id+"'>"+value.name+"</a></td>" +
						"<td class=tablebody2 valign=middle align=center width=''>"+value.price+"</td>" +
						"<td class=tablebody1 valign=middle align=center width=''>" +
						"<a href='shoppingcart.action?productid="+value.id+"'>" +
						"<img border='0' src='images/car_new.gif' width='97' height='18'>" +
						"</a> " +
						"</td>" +
						"</tr>"+
						"<input type='button' value='收起' />"
						);
		    });
			$("#stid").append("<input type='button' value='收起' onclick='clearstid()'>");
			$("#stid").append("</table>");
		}
	})
}

function clearstid(){
	$("#stid").empty();
}





